<?php
/* Scout Events Plugin
This page walks you through creating 
a custom post type and taxonomies. You
can edit this one or copy the following code 
to create another one. 

I put this in a separate file so as to 
keep it organized. I find it easier to edit
and change things if they are concentrated
in their own file.

Developed by: Laurens Lamberty
URL: http://lamberty.me/
*/

// Flush rewrite rules for custom post types
add_action( 'after_switch_theme', 'al3_flush_rewrite_rules_events' );

// Flush your rewrite rules
function al3_flush_rewrite_rules_events() {
	flush_rewrite_rules();
}


// let's create the function for the custom type
function events() { 
	// creating (registering) the custom type 
	register_post_type( 'events', /* (http://codex.wordpress.org/Function_Reference/register_post_type) */
		// let's now add all the options for this post type
		array(
            'labels' => array(
                'name' => __( 'Events', 'al3' ), /* This is the Title of the Group */
                'singular_name' => __( 'Event', 'al3' ), /* This is the individual type */
                'all_items' => __( 'All Events', 'al3' ), /* the all items menu item */
                'add_new' => __( 'Add New', 'al3' ), /* The add new menu item */
                'add_new_item' => __( 'Add New Event', 'al3' ), /* Add New Display Title */
                'edit' => __( 'Edit', 'al3' ), /* Edit Dialog */
                'view_item' => __( 'View Event', 'al3' ), /* View Display Title */
                'search_items' => __( 'Search Events', 'al3' ), /* Search Custom Type Title */ 
                'not_found' =>  __( 'Nothing found in the Database.', 'al3' ), /* This displays if there are no entries yet */ 
                'not_found_in_trash' => __( 'Nothing found in Trash', 'al3' ), /* This displays if there is nothing in the trash */
                'parent_item_colon' => ''
            ), /* end of arrays */
			'description' => __( 'This is were you can add or edit events.', 'al3' ), /* Custom Type Description */
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 5, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => 'dashicons-calendar', /* the icon for the custom post type menu */
			'rewrite'	=> array( 'slug' => __('events', 'al3'), 'with_front' => false ), /* you can specify its url slug */
			'has_archive' => __('events', 'al3'), /* you can rename the slug here */
			'capability_type' => 'post',
			'hierarchical' => false,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'comments', 'revisions', )
		) /* end of options */
	); /* end of register post type */
	
	/* this adds your post categories to the event post type */
	register_taxonomy_for_object_type( 'category', 'event_target_group' );
	
}

// adding the function to the Wordpress init
add_action( 'init', 'events');

/*
for more information on taxonomies, go here:
http://codex.wordpress.org/Function_Reference/register_taxonomy
*/

// now let's add custom categories (these act like categories)
register_taxonomy( 'event_target_group', 
    array('events'), /* if you change the name of register_post_type( 'custom_type', then you have to change this */
    array(
        'hierarchical' => true,     /* if this is true, it acts like categories */
        'labels' => array(
            'name' => __( 'Event Target Groups', 'al3' ), /* name of the custom taxonomy */
            'singular_name' => __( 'Event Target Group', 'al3' ), /* single taxonomy name */
            'search_items' =>  __( 'Search Event Target Groups', 'al3' ), /* search title for taxomony */
            'all_items' => __( 'All Event Target Groups', 'al3' ), /* all title for taxonomies */
            'parent_item' => __( 'Parent Event Target Groups', 'al3' ), /* parent title for taxonomy */
            'parent_item_colon' => __( 'Parent Event Target Group:', 'al3' ), /* parent taxonomy title */
            'edit_item' => __( 'Edit Event Target Group', 'al3' ), /* edit custom taxonomy title */
            'update_item' => __( 'Update Event Target Group', 'al3' ), /* update title for taxonomy */
            'add_new_item' => __( 'Add New Event Target Group', 'al3' ), /* add new title for taxonomy */
            'new_item_name' => __( 'New Event Target Group', 'al3' ) /* name title for taxonomy */
        ),
        'show_admin_column' => true, 
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => __('event_target_group', 'al3') ),
    )
);

/*
    looking for custom meta boxes?
    check out this fantastic tool:
    https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
*/


al3_events_metaboxes();


//Show Metadata in Backend

add_action('manage_posts_custom_column',  'events_custom_columns');
add_filter('manage_events_posts_columns', 'events_edit_columns');
 
function events_edit_columns($columns){
    $columns = array(
        'cb' => '<input type="checkbox" />',
        'title' => __( 'Event', 'al3' ),
        'event_date' => __( 'Date', 'al3' ),
        'event_target_group' => __( 'Target Group', 'al3' ),
        'event_location' => __( 'Location', 'al3' ),
        'event_costs' => __( 'Costs in Euro', 'al3' ),
  );
  return $columns;
}
 
function events_custom_columns($column){
    
    global $post;
    
    $custom = get_post_custom();
    
    switch ($column) {
    case 'event_date':       
        if( ! empty( $custom['event_start_date'][0] ) &&  empty( $custom['event_end_date'][0] )) {
            printf( __('On %s', 'al3'), date_i18n( get_option( 'date_format' ), strtotime( get_field( 'event_start_date' )) ));
                                        }   
        if( ! empty( $custom['event_start_date'][0] ) && ! empty( $custom['event_end_date'][0] )) {
            printf( __('From %1$s to %2$s', 'al3'), date_i18n( get_option( 'date_format' ), strtotime( get_field( 'event_start_date' )) ), date_i18n( get_option( 'date_format' ), strtotime( get_field( 'event_end_date' )) ));
        }

            break;
        
    case 'event_location':
        
            echo $custom['event_location'][0];
        
            break;
         
    case 'event_target_group' :
        
            $postid = get_the_ID(); 
        
			$terms = get_the_terms( $postid, 'event_target_group' );

			if ( !empty( $terms ) ) {
                
                $out = array();

				foreach ( $terms as $term ) {
					$out[] = sprintf( esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'event_target_group', 'display' ) )
					);
				}

				/* Join the terms, separating them with a comma. */
				echo join( ', ', $out );
			}


			break;
        
    case 'event_costs':
        
            echo $custom['event_costs'][0];
        
            break;
    }
}


//Sort Events

add_filter('manage_edit-events_sortable_columns', 'event_date_column_register_sortable');
add_filter('request', 'event_date_column_orderby');
 
function event_date_column_register_sortable( $columns ) {
    $columns['event_date'] = 'event_start_date';
    return $columns;
}
 
function event_date_column_orderby( $vars ) {
    if ( isset( $vars['orderby'] ) && 'event_start_date' == $vars['orderby'] ) {
        $vars = array_merge( $vars, array(
            'meta_key' => 'event_start_date',
            'orderby' => 'meta_value_num'
        ) );
    }
    return $vars;
}

add_filter('manage_edit-events_sortable_columns', 'event_target_group_column_register_sortable');
add_filter('request', 'event_target_group_column_orderby' );

function event_target_group_column_register_sortable( $columns ) {
        $columns['event_target_group'] = 'event_target_group';
        return $columns;
}
 
function event_target_group_column_orderby( $vars ) {
    if ( isset( $vars['orderby'] ) && 'event_target_group' == $vars['orderby'] ) {
        $vars = array_merge( $vars, array(
            'meta_key' => 'event_target_group',
            'orderby' => 'meta_value'
        ) );
    }
    return $vars;
}

add_filter('manage_edit-events_sortable_columns', 'event_location_column_register_sortable');
add_filter('request', 'event_location_column_orderby' );

function event_location_column_register_sortable( $columns ) {
        $columns['event_location'] = 'event_location';
        return $columns;
}
 
function event_location_column_orderby( $vars ) {
    if ( isset( $vars['orderby'] ) && 'event_location' == $vars['orderby'] ) {
        $vars = array_merge( $vars, array(
            'meta_key' => 'event_location',
            'orderby' => 'meta_value'
        ) );
    }
    return $vars;
}

add_filter('manage_edit-events_sortable_columns', 'event_cost_column_register_sortable');
add_filter('request', 'event_costs_column_orderby' );

function event_cost_column_register_sortable( $columns ) {
        $columns['event_costs'] = 'event_costs';
        return $columns;
}
 
function event_costs_column_orderby( $vars ) {
    if ( isset( $vars['orderby'] ) && 'event_costs' == $vars['orderby'] ) {
        $vars = array_merge( $vars, array(
            'meta_key' => 'event_costs',
            'orderby' => 'meta_value'
        ) );
    }
    return $vars;
}