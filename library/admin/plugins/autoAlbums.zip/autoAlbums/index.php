<?php 
  /**
   * @package Auto Albums - Multi Level Responsive Grid by David Blanco
   * @version 1.1
   */
  /*
  Plugin Name: Auto Albums - Multi Level Responsive Grid
  Plugin URI: http://codecanyon.net/user/davidbo90/portfolio
  Description: This is a PHP plugin that scans a folder in your server in which you can put as much images, folders and levels you can imagine and the plugin will make a grid responsive gallery taking the folders as albums. 
  Author: David Blanco
  Version: 1.1
  Author URI: http://codecanyon.net/user/davidbo90
  */

  /* --------------------- OPTIONS PAGE ------------------ */  


  class AAMRG_Options{

      public $options;

      public function __construct(){
          //delete_option('aamrg_plugin_options');
          $this->options = get_option('aamrg_plugin_options');
          $this->register_settings_and_fields();
      }

      public function add_menu_page(){
          add_options_page('Auto Albums Options', 'Auto Albums Options', 'administrator', __FILE__, array('AAMRG_Options', 'display_options_page'));
      }

      public function display_options_page(){
          ?>
          
          <div class="wrap">
            <?php screen_icon(); ?>
            <h2>Auto Albums Default Options</h2>

            <form action="options.php" method="post" enctype="multipart/form-data">
                <?php settings_fields('aamrg_plugin_options'); ?>

                <?php do_settings_sections(__FILE__); ?>

                <p class="submit">
                    <input name="submit" type="submit" class="button-primary" value="Save Changes" />
                </p>

            </form>

          </div>
          
          <?php
      }

      public function register_settings_and_fields(){

          register_setting('aamrg_plugin_options', 'aamrg_plugin_options');//3rd param = optional callback
          add_settings_section('aamrg_main_section', 'Main Settings', array($this, 'aamrg_main_section_cb'), __FILE__);// id, title, cb, which page?

          add_settings_field('aamrg_directory', 'Directory of the Folder ', array($this, 'aamrg_directory_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_imagesOrder', 'Images Order ', array($this, 'aamrg_imagesOrder_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lazyLoad', 'Lazy Load Feature? ', array($this, 'aamrg_lazyLoad_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_folderCoverRandom', 'A Random Folder Cover? ', array($this, 'aamrg_folderCoverRandom_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_foldersAtTop', 'Folders At Top? ', array($this, 'aamrg_foldersAtTop_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_showNumFolder', 'Show Number of Folders? ', array($this, 'aamrg_showNumFolder_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_showNumImages', 'Show Number of Images? ', array($this, 'aamrg_showNumImages_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_autoHideNumFolder', 'Auto Hide Number of Folders? ', array($this, 'aamrg_autoHideNumFolder_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_autoHideNumImage', 'Auto Hide Number of Images? ', array($this, 'aamrg_autoHideNumImage_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_navBar', 'Show Navigation Bar? ', array($this, 'aamrg_navBar_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_imagesToLoadStart', 'Images To Load At Startup ', array($this, 'aamrg_imagesToLoadStart_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_imagesToLoad', 'Images To Load ', array($this, 'aamrg_imagesToLoad_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_horizontalSpace', 'Horizontal Space Between Thumbnails', array($this, 'aamrg_horizontalSpace_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_verticalSpace', 'Vertical Space Between Thumbnails', array($this, 'aamrg_verticalSpace_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_columnWidth', 'Column Width', array($this, 'aamrg_columnWidth_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_columns', 'Number of Columns', array($this, 'aamrg_columns_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_columnMinWidth', 'Minimum Width of Each Column (px)', array($this, 'aamrg_columnMinWidth_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_isAnimated', 'Animated Effects for the Grid?', array($this, 'aamrg_isAnimated_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_caption', 'Show the Captions of the Images?', array($this, 'aamrg_caption_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_captionType', 'The Effect of the Caption', array($this, 'aamrg_captionType_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBox', 'Show the Lightbox?', array($this, 'aamrg_lightBox_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxKeyboard', 'Lightbox Keyboard Navigation?', array($this, 'aamrg_lightBoxKeyboard_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxSpeed', 'Lightbox Speed Effect (ms)', array($this, 'aamrg_lightBoxSpeed_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxZoom', 'Lightbox Zoom Animation?', array($this, 'aamrg_lightBoxZoom_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxText', 'Lightbox Text?', array($this, 'aamrg_lightBoxText_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxPlay', 'Lightbox Play Button?', array($this, 'aamrg_lightBoxPlay_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxAutoPlay', 'Lightbox Auto Play?', array($this, 'aamrg_lightBoxAutoPlay_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxPlayInterval', 'Lightbox Play Interval (ms)', array($this, 'aamrg_lightBoxPlayInterval_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxShowTimer', 'Lightbox Show Timer?', array($this, 'aamrg_lightBoxShowTimer_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_lightBoxStopPlay', 'Stop Play When Lightbox Closes?', array($this, 'aamrg_lightBoxStopPlay_setting'), __FILE__, 'aamrg_main_section');
          add_settings_field('aamrg_hashTag', 'HashTag?', array($this, 'aamrg_hashTag_setting'), __FILE__, 'aamrg_main_section');
      }   

      public function aamrg_main_section_cb(){
          //Optional
      }

      /*
          INPUTS
      */

      public function aamrg_directory_setting(){
          $op = "Gallery";
          if(!empty($this->options['aamrg_directory'])){
              $op = $this->options['aamrg_directory'];
          }

          $parseURL = parse_url(plugin_dir_url( __FILE__ ));
          $path = $parseURL['path'];

          echo $path."<input name='aamrg_plugin_options[aamrg_directory]' type='text' value='{$op}' style='width:200px;' />";
      }

      public function aamrg_imagesOrder_setting(){
          $op = 'byName';
          if(!empty($this->options['aamrg_imagesOrder'])){
              $op = $this->options['aamrg_imagesOrder'];
          }

          $byDate         = "";
          $byDateReverse  = "";
          $byName         = "";
          $byNameReverse  = "";
          $random         = "";


          if($op == 'byDate'){
            $byDate = "selected='selected'";
          }else if($op == 'byDateReverse'){
            $byDateReverse = "selected='selected'";
          }else if($op == 'byName'){
            $byName = "selected='selected'";
          }else if($op == 'byNameReverse'){
            $byNameReverse = "selected='selected'";
          }else if($op == 'random'){
            $random = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_imagesOrder]'>";
            echo "<option $byDate value='byDate'>By Date</option>";
            echo "<option $byDateReverse value='byDateReverse'>By Date Reverse</option>";
            echo "<option $byName value='byName'>By Name</option>";
            echo "<option $byNameReverse value='byNameReverse'>By Name Reverse</option>";
            echo "<option $random value='random'>Randomly</option>";
          echo "</select>";
      }

      public function aamrg_lazyLoad_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_lazyLoad'])){
              $op = $this->options['aamrg_lazyLoad'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lazyLoad]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_folderCoverRandom_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_folderCoverRandom'])){
              $op = $this->options['aamrg_folderCoverRandom'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_folderCoverRandom]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_foldersAtTop_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_foldersAtTop'])){
              $op = $this->options['aamrg_foldersAtTop'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_foldersAtTop]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_showNumFolder_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_showNumFolder'])){
              $op = $this->options['aamrg_showNumFolder'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_showNumFolder]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_showNumImages_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_showNumImages'])){
              $op = $this->options['aamrg_showNumImages'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_showNumImages]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_autoHideNumFolder_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_autoHideNumFolder'])){
              $op = $this->options['aamrg_autoHideNumFolder'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_autoHideNumFolder]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_autoHideNumImage_setting(){
          $op = 'false';
          if(!empty($this->options['aamrg_autoHideNumImage'])){
              $op = $this->options['aamrg_autoHideNumImage'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_autoHideNumImage]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_navBar_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_navBar'])){
              $op = $this->options['aamrg_navBar'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_navBar]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_imagesToLoadStart_setting(){
          $op = "15";
          if(!empty($this->options['aamrg_imagesToLoadStart'])){
              $op = $this->options['aamrg_imagesToLoadStart'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_imagesToLoadStart]' type='number' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_imagesToLoad_setting(){
          $op = "5";
          if(!empty($this->options['aamrg_imagesToLoad'])){
              $op = $this->options['aamrg_imagesToLoad'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_imagesToLoad]' type='number' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_horizontalSpace_setting(){
          $op = "5";
          if(!empty($this->options['aamrg_horizontalSpace'])){
              $op = $this->options['aamrg_horizontalSpace'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_horizontalSpace]' type='number' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_verticalSpace_setting(){
          $op = "5";
          if(!empty($this->options['aamrg_verticalSpace'])){
              $op = $this->options['aamrg_verticalSpace'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_verticalSpace]' type='number' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_columnWidth_setting(){
          $op = "auto";
          if(!empty($this->options['aamrg_columnWidth'])){
              $op = $this->options['aamrg_columnWidth'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_columnWidth]' type='text' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_columns_setting(){
          $op = "5";
          if(!empty($this->options['aamrg_columns'])){
              $op = $this->options['aamrg_columns'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_columns]' type='number' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_columnMinWidth_setting(){
          $op = "220";
          if(!empty($this->options['aamrg_columnMinWidth'])){
              $op = $this->options['aamrg_columnMinWidth'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_columnMinWidth]' type='number' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_isAnimated_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_isAnimated'])){
              $op = $this->options['aamrg_isAnimated'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_isAnimated]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_caption_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_caption'])){
              $op = $this->options['aamrg_caption'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_caption]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_captionType_setting(){
          $op = 'Grid';
          if(!empty($this->options['aamrg_captionType'])){
              $op = $this->options['aamrg_captionType'];
          }

          $grid           = "";
          $gridFade       = "";
          $classic         = "";


          if($op == 'grid'){
            $grid = "selected='selected'";
          }else if($op == 'grid-fade'){
            $gridFade = "selected='selected'";
          }else if($op == 'classic'){
            $classic = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_captionType]'>";
            echo "<option $grid value='grid'>Grid</option>";
            echo "<option $gridFade value='grid-fade'>Grid Fade</option>";
            echo "<option $classic value='classic'>Classic</option>";
          echo "</select>";
      }

      public function aamrg_lightBox_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_lightBox'])){
              $op = $this->options['aamrg_lightBox'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lightBox]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_lightBoxKeyboard_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_lightBoxKeyboard'])){
              $op = $this->options['aamrg_lightBoxKeyboard'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lightBoxKeyboard]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_lightBoxSpeed_setting(){
          $op = "500";
          if(!empty($this->options['aamrg_lightBoxSpeed'])){
              $op = $this->options['aamrg_lightBoxSpeed'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_lightBoxSpeed]' type='number' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_lightBoxZoom_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_lightBoxZoom'])){
              $op = $this->options['aamrg_lightBoxZoom'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lightBoxZoom]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_lightBoxText_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_lightBoxText'])){
              $op = $this->options['aamrg_lightBoxText'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lightBoxText]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_lightBoxPlay_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_lightBoxPlay'])){
              $op = $this->options['aamrg_lightBoxPlay'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lightBoxPlay]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_lightBoxAutoPlay_setting(){
          $op = 'false';
          if(!empty($this->options['aamrg_lightBoxAutoPlay'])){
              $op = $this->options['aamrg_lightBoxAutoPlay'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lightBoxAutoPlay]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_lightBoxPlayInterval_setting(){
          $op = "4000";
          if(!empty($this->options['aamrg_lightBoxPlayInterval'])){
              $op = $this->options['aamrg_lightBoxPlayInterval'];
          }

          echo "<input name='aamrg_plugin_options[aamrg_lightBoxPlayInterval]' type='number' value='{$op}' style='width:80px;' />";
      }

      public function aamrg_lightBoxShowTimer_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_lightBoxShowTimer'])){
              $op = $this->options['aamrg_lightBoxShowTimer'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lightBoxShowTimer]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_lightBoxStopPlay_setting(){
          $op = 'false';
          if(!empty($this->options['aamrg_lightBoxStopPlay'])){
              $op = $this->options['aamrg_lightBoxStopPlay'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_lightBoxStopPlay]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }

      public function aamrg_hashTag_setting(){
          $op = 'true';
          if(!empty($this->options['aamrg_hashTag'])){
              $op = $this->options['aamrg_hashTag'];
          }

          $no = "";
          if($op == 'false'){
            $no = "selected='selected'";
          }

          echo "<select name='aamrg_plugin_options[aamrg_hashTag]'>";
            echo "<option value='true'>Yes</option>";
            echo "<option value='false' $no>No</option>";
          echo "</select>";
      }



  }

  add_action('admin_menu', 'initOptionsAAMRG');

  function initOptionsAAMRG(){
      AAMRG_Options::add_menu_page();
  }

  add_action('admin_init', 'initAdminAAMRG');

  function initAdminAAMRG(){
    
      new AAMRG_Options();
  }

  

  /* 
  *
  *
  *
  *
  *
  -------------------------------------------- END OF OPTIONS PAGE --------------------------------------------
  *
  *
  *
  *
  *
  */

  /* --------------------- STYLE AND SCRIPTS ------------------ */  

  function AutoAlbums_scripts()  
  {  
      // Register the script like this for a plugin:  
      wp_register_script( 'aamrg-script-rotate', plugins_url( '/js/rotate-patch.js', __FILE__ ), array( 'jquery' ) );  
      
      // For either a plugin or a theme, you can then enqueue the script:  
      wp_enqueue_script( 'aamrg-script-rotate' );

      // Register the script like this for a plugin:  
      wp_register_script( 'aamrg-script', plugins_url( '/js/autoAlbums.min.js', __FILE__ ), array( 'jquery' ) );  
      
      // For either a plugin or a theme, you can then enqueue the script:  
      wp_enqueue_script( 'aamrg-script' );  

      // Register the script like this for a plugin:  
      wp_register_script( 'aamrg-script-init', plugins_url( 'autoAlbums.js', __FILE__ ), array( 'jquery' ) );  
      
      // For either a plugin or a theme, you can then enqueue the script:  
      wp_enqueue_script( 'aamrg-script-init' ); 

      //Pass default options to the script ----------------->
      $options = get_option('aamrg_plugin_options');
      
      $imgOrder   = "byName";
      if(!empty($options['aamrg_imagesOrder'])){$imgOrder = $options['aamrg_imagesOrder'];}

      $folderCoverRandom   = true;
      if(!empty($options['aamrg_folderCoverRandom'])){$folderCoverRandom = $options['aamrg_folderCoverRandom']=='true'?true:false;}

      $lazyLoad   = true;
      if(!empty($options['aamrg_lazyLoad'])){$lazyLoad = $options['aamrg_lazyLoad']=='true'?true:false;}

      $foldersAtTop   = true;
      if(!empty($options['aamrg_foldersAtTop'])){$foldersAtTop = $options['aamrg_foldersAtTop']=='true'?true:false;}

      $showNumFolder   = true;
      if(!empty($options['aamrg_showNumFolder'])){$showNumFolder = $options['aamrg_showNumFolder']=='true'?true:false;}

      $showNumImages   = true;
      if(!empty($options['aamrg_showNumImages'])){$showNumImages = $options['aamrg_showNumImages']=='true'?true:false;}

      $autoHideNumFolder   = true;
      if(!empty($options['aamrg_autoHideNumFolder'])){$autoHideNumFolder = $options['aamrg_autoHideNumFolder']=='true'?true:false;}

      $autoHideNumImage   = false;
      if(!empty($options['aamrg_autoHideNumImage'])){$autoHideNumImage = $options['aamrg_autoHideNumImage']=='true'?true:false;}

      $showNavBar   = true;
      if(!empty($options['aamrg_navBar'])){$showNavBar = $options['aamrg_navBar']=='true'?true:false;}

      $imagesToLoadStart   = "15";
      if(!empty($options['aamrg_imagesToLoadStart'])){$imagesToLoadStart = $options['aamrg_imagesToLoadStart'];}

      $imagesToLoad   = "5";
      if(!empty($options['aamrg_imagesToLoad'])){$imagesToLoad = $options['aamrg_imagesToLoad'];}

      $horizontalSpace   = "5";
      if(!empty($options['aamrg_horizontalSpace'])){$horizontalSpace = $options['aamrg_horizontalSpace'];}

      $verticalSpace   = "5";
      if(!empty($options['aamrg_verticalSpace'])){$verticalSpace = $options['aamrg_verticalSpace'];}

      $columnWidth   = "auto";
      if(!empty($options['aamrg_columnWidth'])){$columnWidth = $options['aamrg_columnWidth'];}

      $columns   = "5";
      if(!empty($options['aamrg_columns'])){$columns = $options['aamrg_columns'];}

      $columnMinWidth   = "220";
      if(!empty($options['aamrg_columnMinWidth'])){$columnMinWidth = $options['aamrg_columnMinWidth'];}

      $isAnimated   = true;
      if(!empty($options['aamrg_isAnimated'])){$isAnimated = $options['aamrg_isAnimated']=='true'?true:false;}

      $caption   = true;
      if(!empty($options['aamrg_caption'])){$caption = $options['aamrg_caption']=='true'?true:false;}

      $captionType   = "grid";
      if(!empty($options['aamrg_captionType'])){$captionType = $options['aamrg_captionType'];}

      $lightbox   = true;
      if(!empty($options['aamrg_lightBox'])){$lightbox = $options['aamrg_lightBox']=='true'?true:false;}

      $lightboxKeyboardNav   = true;
      if(!empty($options['aamrg_lightBoxKeyboard'])){$lightboxKeyboardNav = $options['aamrg_lightBoxKeyboard']=='true'?true:false;}

      $lightBoxSpeedFx   = "500";
      if(!empty($options['aamrg_lightBoxSpeed'])){$lightBoxSpeedFx = $options['aamrg_lightBoxSpeed'];}

      $lightboxZoom   = true;
      if(!empty($options['aamrg_lightBoxZoom'])){$lightboxZoom = $options['aamrg_lightBoxZoom']=='true'?true:false;}

      $lightBoxText   = true;
      if(!empty($options['aamrg_lightBoxText'])){$lightBoxText = $options['aamrg_lightBoxText']=='true'?true:false;}

      $lightboxPlayBtn   = true;
      if(!empty($options['aamrg_lightBoxPlay'])){$lightboxPlayBtn = $options['aamrg_lightBoxPlay']=='true'?true:false;}

      $lightBoxAutoPlay   = false;
      if(!empty($options['aamrg_lightBoxAutoPlay'])){$lightBoxAutoPlay = $options['aamrg_lightBoxAutoPlay']=='true'?true:false;}

      $lightBoxPlayInterval   = "4000";
      if(!empty($options['aamrg_lightBoxPlayInterval'])){$lightBoxPlayInterval = $options['aamrg_lightBoxPlayInterval'];}

      $lightBoxShowTimer   = true;
      if(!empty($options['aamrg_lightBoxShowTimer'])){$lightBoxShowTimer = $options['aamrg_lightBoxShowTimer']=='true'?true:false;}

      $lightBoxStopPlayOnClose   = false;
      if(!empty($options['aamrg_lightBoxStopPlay'])){$lightBoxStopPlayOnClose = $options['aamrg_lightBoxStopPlay']=='true'?true:false;}

      $hashTag   = true;
      if(!empty($options['aamrg_hashTag'])){$hashTag = $options['aamrg_hashTag']=='true'?true:false;}

      wp_localize_script( 'aamrg-script-init', 'aamrg_vars', array('imgOrder'          => $imgOrder,
                                                                  'lazyLoad'          => $lazyLoad,
                                                                  'folderCoverRandom' => $folderCoverRandom,
                                                                  'foldersAtTop'      => $foldersAtTop,
                                                                  'showNumFolder'     => $showNumFolder,
                                                                  'showNumImages'     => $showNumImages,
                                                                  'autoHideNumFolder' => $autoHideNumFolder,
                                                                  'autoHideNumImage'  => $autoHideNumImage,
                                                                  'showNavBar'        => $showNavBar,
                                                                  'imagesToLoadStart' => $imagesToLoadStart,
                                                                  'imagesToLoad'      => $imagesToLoad,
                                                                  'horizontalSpace'   => $horizontalSpace,
                                                                  'verticalSpace'     => $verticalSpace,
                                                                  'columnWidth'       => $columnWidth,
                                                                  'columns'           => $columns,
                                                                  'columnMinWidth'    => $columnMinWidth,
                                                                  'isAnimated'        => $isAnimated,
                                                                  'caption'           => $caption,
                                                                  'captionType'       => $captionType,
                                                                  'lightbox'          => $lightbox,
                                                                  'lightboxKeyboardNav' => $lightboxKeyboardNav,
                                                                  'lightBoxSpeedFx'   => $lightBoxSpeedFx,
                                                                  'lightboxZoom'      => $lightboxZoom,
                                                                  'lightBoxText'      => $lightBoxText,
                                                                  'lightboxPlayBtn'   => $lightboxPlayBtn,
                                                                  'lightBoxAutoPlay'  => $lightBoxAutoPlay,
                                                                  'lightBoxPlayInterval' => $lightBoxPlayInterval,
                                                                  'lightBoxShowTimer' => $lightBoxShowTimer,
                                                                  'lightBoxStopPlayOnClose' => $lightBoxStopPlayOnClose,
                                                                  'hashTag'           => $hashTag  ) );


     
      if($lazyLoad){
          // Register the script like this for a plugin:  
          wp_register_script( 'aamrg-script-waypoints', plugins_url( '/js/waypoints.min.js', __FILE__ ), array( 'jquery' ) );  
          
          // For either a plugin or a theme, you can then enqueue the script:  
          wp_enqueue_script( 'aamrg-script-waypoints' );
      }
  }  

  function AutoAlbums_styles()  
  {  
      //GRID STYLE
      wp_register_style( 'aamrg-style', plugins_url( '/css/autoAlbums.css', __FILE__ ), array(), '20120208', 'all' );  
      wp_enqueue_style( 'aamrg-style' );  
  }  

  
  add_action( 'wp_enqueue_scripts', 'AutoAlbums_styles' );
  add_action( 'wp_enqueue_scripts', 'AutoAlbums_scripts' ); 

  /* --------------------- END STYLE AND SCRIPTS ------------------ */  


  /* --------------------- SHORTCODE ------------------ */  

  add_shortcode( 'autoAlbums', 'auto_albums' );


  function auto_albums( $atts, $content = false ) {

      $options = get_option('aamrg_plugin_options');

      $directory   = "Gallery";
      if( !empty($options['aamrg_directory']) ){$directory = $options['aamrg_directory'];}
      if( !empty($atts['directory']) ){$directory = $atts['directory'];}

      $parseURL = parse_url(plugin_dir_url( __FILE__ ));
      $path = $parseURL['path'];

      $site = get_site_url();
      $site2 = str_replace("//", "@@", $site);
      $site3 = explode("/", $site2);
      $site4 = str_replace("@@", "//", $site3[0]);

      return "<div class='AutoAlbums' data-directory='$directory' data-path='$path' data-site='$site4'></div>";

  }
?>